create procedure sp_usersupdate_save(IN piduser      int, IN pdesperson varchar(64), IN pdeslogin varchar(64),
                                     IN pdespassword varchar(256), IN pdesemail varchar(128), IN pnrphone bigint,
                                     IN pinadmin     tinyint)
  BEGIN
	
    DECLARE vidperson INT;
    
	SELECT idperson INTO vidperson
    FROM tb_users
    WHERE iduser = piduser;
    
    UPDATE tb_persons
    SET 
		desperson = pdesperson,
        desemail = pdesemail,
        nrphone = pnrphone
	WHERE idperson = vidperson;
    
    UPDATE tb_users
    SET
		deslogin = pdeslogin,
        despassword = pdespassword,
        inadmin = pinadmin
	WHERE iduser = piduser;
    
    SELECT * FROM tb_users a INNER JOIN tb_persons b USING(idperson) WHERE a.iduser = piduser;
    
END;

